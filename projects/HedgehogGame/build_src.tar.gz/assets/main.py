import pygame
import random
import sys
import math  # for animation
import asyncio

# --- CONFIGURATION ---
WIDTH = 800
HEIGHT = 600
FPS = 60

# --- COLORS ---
WHITE = (255, 255, 255)
RED = (220, 20, 60)
JUICE_COLOR = (240, 230, 140)  # Color of apple inside

# --- INITIALIZE PYGAME ---
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Super Hedgehog Adventure")
clock = pygame.time.Clock()


# --- ASSET LOADING ---
def load_image(name, scale_size, fallback_color):
    try:
        img = pygame.image.load(name).convert_alpha()
        if scale_size:
            img = pygame.transform.scale(img, scale_size)
        return img
    except FileNotFoundError:
        surface = pygame.Surface(scale_size if scale_size else (50, 50))
        surface.fill(fallback_color)
        if "background" in name and scale_size:
            # Draw simple grass if bg missing
            pygame.draw.rect(surface, (160, 215, 90), (0, scale_size[1] - 40, scale_size[0], 40))
        return surface


# Load images
bg_img = load_image("background.png", (WIDTH, HEIGHT), (200, 240, 255))
bg_img_lvl2 = load_image("background3.png", (WIDTH, HEIGHT), (50, 50, 100)) # Darker/Different for Level 2
hedgehog_img = load_image("hhog.png", (270, 170), (139, 69, 19))
apple_img = load_image("apple.png", (45, 45), (255, 0, 0))

# Font
try:
    font_large = pygame.font.Font(None, 70)
    font_small = pygame.font.Font(None, 40)
except:
    font_large = pygame.font.SysFont("Arial", 50)
    font_small = pygame.font.SysFont("Arial", 30)


# --- CLASSES ---

class Player:
    def __init__(self):
        self.original_image = hedgehog_img
        self.rect = self.original_image.get_rect()
        self.rect.midbottom = (WIDTH // 2, HEIGHT - 25)

        # Physics variables
        self.vel_x = 0
        self.speed = 0.3
        self.friction = 0.95
        self.max_speed = 9

        # ANIMATION VARIABLES
        self.waddle_timer = 0
        self.facing_right = True

    def move(self, keys):
        # Apply Acceleration
        if keys[pygame.K_LEFT]:
            self.vel_x -= self.speed
            self.facing_right = False  # Remember direction
        if keys[pygame.K_RIGHT]:
            self.vel_x += self.speed
            self.facing_right = True  # Remember direction

        # Apply Friction
        self.vel_x *= self.friction

        # Limit Max Speed
        if self.vel_x > self.max_speed: self.vel_x = self.max_speed
        if self.vel_x < -self.max_speed: self.vel_x = -self.max_speed

        # Update Position
        self.rect.x += self.vel_x

        # Screen Boundaries
        if self.rect.left < 0:
            self.rect.left = 0
            self.vel_x = -self.vel_x * 0.5
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
            self.vel_x = -self.vel_x * 0.5

    def draw(self, surface):
        # --- ANIMATION LOGIC ---

        is_moving = abs(self.vel_x) > 0.5

        if is_moving:
            # WADDLE (Running)
            self.waddle_timer += 0.4  # Speed of waddle
            angle = math.sin(self.waddle_timer) * 7  # Tilt left and right (-7 to +7 degrees)
            scale_y = 0
        else:
            # BREATHE (Idle)
            self.waddle_timer += 0.08  # Slow breath speed
            angle = 0
            # Squish and stretch (up and down by 4 pixels)
            scale_y = math.sin(self.waddle_timer) * 4

        # --- TRANSFORMATION ---

        # 1. Handle Breathing (Scaling)
        current_img = self.original_image
        if scale_y != 0:
            w, h = current_img.get_size()
            # Stretch height slightly
            current_img = pygame.transform.scale(current_img, (w, int(h + scale_y)))

        # 2. Handle Direction (Flipping)
        if not self.facing_right:
            current_img = pygame.transform.flip(current_img, True, False)

        # 3. Handle Waddle (Rotation)
        if angle != 0:
            current_img = pygame.transform.rotate(current_img, angle)

        # 4. Re-center image so feet stay on ground
        draw_rect = current_img.get_rect()
        draw_rect.midbottom = self.rect.midbottom

        surface.blit(current_img, draw_rect)


class Apple:
    def __init__(self, speed_min=3, speed_max=5):
        self.original_image = apple_img
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(40, WIDTH - 40)
        self.rect.y = -50
        self.speed_y = random.uniform(speed_min, speed_max)

        # Rotation
        self.angle = 0
        self.rotation_speed = random.choice([-2, -1, 1, 2])

    def update(self):
        self.rect.y += self.speed_y
        self.angle += self.rotation_speed

        # Rotate image logic
        self.image = pygame.transform.rotate(self.original_image, self.angle)
        old_center = self.rect.center
        self.rect = self.image.get_rect()
        self.rect.center = old_center

    def draw(self, surface):
        # the apple PULSE (grow/shrink) slightly
        # Calculate pulse size using time
        pulse = math.sin(pygame.time.get_ticks() * 0.005) * 4

        w, h = self.image.get_size()
        # Create pulsed image
        pulsing_apple = pygame.transform.scale(self.image, (int(w + pulse), int(h + pulse)))

        # Draw centered
        draw_pos = pulsing_apple.get_rect(center=self.rect.center)
        surface.blit(pulsing_apple, draw_pos)


class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.size = random.randint(4, 8)
        self.color = color
        self.vel_x = random.uniform(-3, 3)
        self.vel_y = random.uniform(-5, -1)
        self.gravity = 0.2
        self.life = 1.0

    def update(self):
        self.vel_y += self.gravity
        self.x += self.vel_x
        self.y += self.vel_y
        self.life -= 0.03

    def draw(self, surface):
        if self.life > 0:
            s = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
            s.fill((*self.color, int(255 * self.life)))
            surface.blit(s, (int(self.x), int(self.y)))


# --- GAME SETUP ---
player = Player()
apples = []
particles = []
score = 0
lives = 5
level = 1
game_state = "PLAYING"
current_bg = bg_img

# --- MAIN LOOP ---
async def main():
    global player, apples, particles, score, lives, level, game_state, current_bg
    running = True
    while running:
        # 1. EVENT HANDLING
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_state == "GAMEOVER":
                    apples = []
                    particles = []
                    score = 0
                    lives = 5
                    level = 1
                    current_bg = bg_img
                    game_state = "PLAYING"

        keys = pygame.key.get_pressed()

        # Draw Background
        screen.blit(current_bg, (0, 0))

        if game_state == "PLAYING":
            player.move(keys)

            # Spawn Apples
            if random.randint(1, 60) == 1:
                if level == 1:
                    apples.append(Apple(3, 5))
                else:
                    apples.append(Apple(4, 6)) # Faster apples for level 2

            # Update Apples
            for apple in apples[:]:
                apple.update()

                # Caught by Hedgehog
                if player.rect.inflate(-20, -20).colliderect(apple.rect):
                    apples.remove(apple)
                    score += 10

                    # Level Up Check
                    if score >= 200 and level == 1:
                        level = 2
                        current_bg = bg_img_lvl2
                        lives = 5 # Restore lives


                    for _ in range(5):
                        particles.append(Particle(apple.rect.centerx, apple.rect.centery, JUICE_COLOR))

                # Hit the ground
                elif apple.rect.y > HEIGHT:
                    apples.remove(apple)
                    lives -= 1
                    for _ in range(10):
                        particles.append(Particle(apple.rect.centerx, HEIGHT - 10, RED))

                    if lives <= 0:
                        game_state = "GAMEOVER"

            # Update Particles
            for p in particles[:]:
                p.update()
                if p.life <= 0:
                    particles.remove(p)

            # --- DRAW ---
            player.draw(screen)
            for apple in apples:
                apple.draw(screen)
            for p in particles:
                p.draw(screen)

            # UI
            score_text = font_small.render(f"Score: {score}", True, WHITE)
            lives_text = font_small.render(f"Lives: {lives}", True, RED)
            level_text = font_small.render(f"Level: {level}", True, JUICE_COLOR)
            screen.blit(score_text, (20, 20))
            screen.blit(lives_text, (WIDTH - 150, 20))
            screen.blit(level_text, (WIDTH // 2 - 50, 20))

        elif game_state == "GAMEOVER":
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            screen.blit(overlay, (0, 0))

            over_text = font_large.render("GAME OVER", True, RED)
            restart_text = font_small.render("Press 'R' to Restart", True, WHITE)

            screen.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 2 - 50))
            screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 20))

        pygame.display.flip()
        clock.tick(FPS)

        # Yield control to the browser (required by Pygbag)
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())